package com.example.ais;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import android.graphics.Bitmap;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.Handler;
import android.speech.tts.TextToSpeech;
import android.util.Base64;
import android.util.FloatMath;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.otaliastudios.cameraview.BitmapCallback;
import com.otaliastudios.cameraview.CameraListener;
import com.otaliastudios.cameraview.CameraView;
import com.otaliastudios.cameraview.PictureResult;
import com.otaliastudios.cameraview.controls.Mode;

import java.io.ByteArrayOutputStream;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity implements SensorEventListener {
    private TextView xText, yText, zText;
    private Sensor mySensor;
    private SensorManager SM;
    Timer timer = new Timer();
    TextToSpeech t1;
    public TextToSpeech finalT = t1;
    public float mAccel = 0;
    public boolean state = false;
    private String imageToString(Bitmap image) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        image.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
        byte[] byteArray = byteArrayOutputStream .toByteArray();
        String encoded = Base64.encodeToString(byteArray, Base64.DEFAULT);
        return encoded;
    }


    private void captionPhoto(Bitmap image) {
        String encodedImage = imageToString(image);
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://192.168.31.39:5000")
                //IP del local host o ordenador donde corre el servicio
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        CaptionService captionService = retrofit.create(CaptionService.class);
        Call<Caption> call = captionService.test(encodedImage);
        call.enqueue(new Callback<Caption>() {
            @Override
            public void onResponse(Call<Caption> call, final Response<Caption> response)
            {   //showToast("funcion de descripcion!");
                //Aqui tenemos la respuesta
                //textView.setText(response.body().getText());
                //Hacer text to speech
                String response2speech = response.body().getText();
                //showToast(response2speech);
                int speech = t1.speak(response2speech , TextToSpeech.QUEUE_FLUSH,null);
            }
            //Si falla muestra error
            @Override
            public void onFailure(Call<Caption> call, Throwable t) {
                //textView.setText("Error");
                t.printStackTrace();
            }
        });
    }





    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final CameraView camera = findViewById(R.id.camera);
        camera.setMode(Mode.PICTURE); // for pictures
        camera.setLifecycleOwner(this);
        camera.addCameraListener(new CameraListener() {
            @Override
            public void onPictureTaken(PictureResult result) {

                result.toBitmap(new BitmapCallback() {
                    @Override
                    public void onBitmapReady(@Nullable Bitmap bitmap) {
                        System.out.println(bitmap.getWidth() + "x" + bitmap.getHeight());
                        captionPhoto(bitmap);
                    }

                });
                // If planning to save a file on a background thread,
                // just use toFile. Ensure you have permissions.
                //result.toFile(file, callback);
                System.out.println(result.getSize().getWidth() + "x" + result.getSize().getHeight());
            }
        });

        SM = (SensorManager)getSystemService(SENSOR_SERVICE);
        mySensor = SM.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        SM.registerListener(this, mySensor,SensorManager.SENSOR_DELAY_NORMAL);

        xText=findViewById(R.id.xText);
        yText=findViewById(R.id.yText);
        zText=findViewById(R.id.zText);


        //Controlar estado del boton
        Button btn = findViewById(R.id.button);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //camera.takePictureSnapshot();

                if ( state ) {
                    state=false;
                    String ini = "Stop";
                    int inispe = t1.speak(ini ,TextToSpeech.QUEUE_FLUSH,null);  //speak after 1000ms

                } else {
                    String ini = "Start";
                    int inispe = t1.speak(ini ,TextToSpeech.QUEUE_FLUSH,null);  //speak after 1000ms
                    state = true;

                }
            }
        });

        //Llamar a la funcion de descripcion cada 5 segundos si pulsan el boton
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                if(state) {
                    if(mAccel<10 && mAccel>9) {
                        camera.takePictureSnapshot();
                    }
                }
            }
        }, 1000, 5000);


        //public TextToSpeech finalT = t1;
        t1 = new TextToSpeech(getApplicationContext()
                , new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int i) {
                if (i == TextToSpeech.SUCCESS) {
                    int lang = t1.setLanguage(Locale.ENGLISH);
                }
            }
        });
        //Mensajes de bienvenida
        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                String ini = "Welcome to your eyes, point your phone's camera and you will get the description";
                int inispe = t1.speak(ini ,TextToSpeech.QUEUE_FLUSH,null);  //speak after 1000ms

            }
        }, 1000);
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                String inii = "If you want to start, touch the lower part of your screen, for stop touch again";
                int inispe2 = t1.speak(inii ,TextToSpeech.QUEUE_FLUSH,null);  //speak after 1000ms
            }
        }, 5000);

    }

    @Override
    public void onSensorChanged(SensorEvent event) {

        xText.setText("X  " + event.values[0] );
        yText.setText("Y  " + event.values[1]);
        zText.setText("Z  " + event.values[2]);

        float x = event.values[0];
        float y = event.values[1];
        float z = event.values[2];


        float mAccelCurrent = (float)Math.sqrt(x*x + y*y + z*z);
        mAccel= mAccel * 0.1f + mAccelCurrent * 0.9f;
        //Log.d("onSensorChanged",System.currentTimeMillis()+","+mAccelCurrent +","+mAccel);
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {
        //Not in use
    }

    /*  private void showToast(final String text) {
        runOnUiThread(new Runnable() {
                          @Override
                          public void run() {
                              Toast.makeText(MainActivity.this.getApplicationContext(), text, Toast.LENGTH_SHORT).show();
                          }
                      }
        );
    }*/
}
